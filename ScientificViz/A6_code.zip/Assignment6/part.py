import numpy as np
import matplotlib.pyplot as plt

# Set the random seed for reproducibility
np.random.seed(42)

# Define the function f(x) = sin(10x) + sin(20x)
def f(x):
    return np.sin(10*3.14*x) + np.sin(20*3.14*x)

# Define the number of points and instances
n_points = 100
n_instances = 100

# Generate the uniform array in x
x = np.linspace(0, 1, n_points)

# Generate the noisy y-values for each instance
ys = []
for i in range(n_instances):
    y = f(x) + np.random.normal(loc=0, scale=abs(f(x))/2, size=n_points)
    ys.append(y)

# Plot each instance as a line with some transparency
# for y in ys:
#     plt.plot(x, y, alpha=0.5)

mean_y = np.mean(ys, axis=0)
std_y = np.std(ys, axis=0)

# Plot the mean and one standard deviation
plt.plot(x, mean_y, color='blue', label='Mean')
plt.fill_between(x, mean_y-std_y, mean_y+std_y, color='blue', alpha=0.2, label='One Standard Deviation')

# Add labels and title
plt.xlabel('x')
plt.ylabel('y')
plt.title('100 Instances of Noisy Data with Uncertainty')

# Show the plot
plt.show()
