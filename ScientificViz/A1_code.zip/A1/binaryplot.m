function A = binaryplot(data)
    fileID = fopen('test.bin','w');
    fwrite(fileID,data, 'double');
    fclose(fileID);
    fileID = fopen('test.bin');
    A = fread(fileID,'double');
    fclose(fileID);
end
