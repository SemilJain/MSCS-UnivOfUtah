import pandas as pd
import matplotlib.pyplot as plt
import plotly.graph_objects as go
import numpy as np

# Plot bar chart with colors
data = np.genfromtxt('https://my.eng.utah.edu/~cs6635/NOAA-Temperatures.csv', delimiter=',', dtype=None, names=True, skip_header=4)
X = data['Year']
Y = data['Value']
colors = ["red" if i > 0 else "blue" for i in Y]
plt.bar(X, Y, color=colors)
plt.xlabel("Years")
plt.ylabel("Degrees F +/- from Average")
plt.show()


# Plot radar chart
data1 = pd.read_excel('https://my.eng.utah.edu/~cs6635/Breakfast-Cereals.xls', header=None, usecols='D:J,L', skip_footer=74)
data1 = pd.DataFrame(data1)
categories = list(data1.iloc[0])
data1[0] = pd.to_numeric(data1[0][1:])
data1[0] = data1[0][1:]/100
data1[3] = pd.to_numeric(data1[3][1:])
data1[3] = data1[3][1:]/100
data1[7] = pd.to_numeric(data1[7][1:])
data1[7] = data1[7][1:]/100
fig = go.Figure()

fig.add_trace(go.Scatterpolar(
    r=list(data1.iloc[1]),
    theta=categories,
    fill='toself',
    name='Apple Cinnamon Cheerios'
))
fig.add_trace(go.Scatterpolar(
    r=list(data1.iloc[2]),
    theta=categories,
    fill='toself',
    name='Basic 4'
))
fig.add_trace(go.Scatterpolar(
    r=list(data1.iloc[3]),
    theta=categories,
    fill='toself',
    name='Cheerios'
))
fig.update_layout(
    polar=dict(
        radialaxis=dict(
            visible=True,
            range=[0, 18]
        )),
    showlegend=True
)
fig.show()


# Plot Scatter plot
data = np.genfromtxt('./recentgrads.csv', delimiter=',', dtype=None, names=True, skip_header=0, encoding=None)
X = data['ShareWomen']*100
Y = data['Median']
plt.scatter(X, Y, marker='*')
plt.xlabel("Percentage of Women in a Major")
plt.ylabel("Median Salary in a Major")
plt.show()

# Plot parallel coords chart
df = pd.read_csv("./fandango.csv", usecols=['FILM', 'RT_norm', 'Metacritic_norm', 'IMDB_norm', 'Fandango_Ratingvalue'])
fig = pd.plotting.parallel_coordinates(df, 'FILM')
fig.legend_.remove()
plt.ylabel("Ratings")
plt.show(block=True)

