rng('default');
r1 = rand(1,100);
r2 = normrnd(50,17,[1,200]);

f1 = figure;
subplot(1,2,1);
ax1 = boxplot(r1);
title('Uniform Random Distribution');
subplot(1,2,2); 
ax2 = boxplot(r2);
title('Gaussian Random Distribution');

[N1,edges1] = histcounts(r1,20);
[N2,edges2] = histcounts(r2,20);
f2 = figure;
subplot(1,2,1);
ax1 = bar(edges1(2:21), N1);
xlabel('bin ranges');
ylabel('frequency in bins');
title('Uniform Random Distribution');
subplot(1,2,2); 
ax2 = bar(edges2(2:21), N2);
xlabel('bin ranges');
ylabel('frequency in bins');
title('Gaussian Random Distribution');

f3 = figure;
subplot(1,2,1);
ax1 = cdfplot(binaryplot(r1));
xlabel('binary file values');
ylabel('Cumulative probablity');
title('Uniform Random Distribution');
subplot(1,2,2); 
ax2 = cdfplot(binaryplot(r2));
xlabel('binary file values');
ylabel('Cumulative probablity');
title('Gaussian Random Distribution');


r3 = rand(2,5000);
r4 = normrnd(0.5,0.17,[2,5000]);

f4a = figure;
subplot(1,2,1);
ax1 = scatter(r3(1,:),r3(2,:));
xlabel('x coords');
ylabel('y coords');
title('Uniform Random Distribution');
subplot(1,2,2); 
ax2 = scatter(r4(1,:),r4(2,:));
xlabel('x coords');
ylabel('y coords');
title('Gaussian Random Distribution');

 
[N3,Xedges3,Yedges3] = histcounts2(r3(1,:),r3(2,:),100);
[N4,Xedges4,Yedges4] = histcounts2(r4(1,:),r4(2,:),100);

f4b = figure;
subplot(1,2,1);
ax1 = image(N3);
set(gca,'YDir','normal');
xlabel('x bins');
ylabel('y bins');
title('Uniform Random Distribution');
subplot(1,2,2); 
ax2 = image(N4);
set(gca,'YDir','normal');

xlabel('x bins');
ylabel('y bins');
title('Gaussian Random Distribution');

f4c = figure;
subplot(1,2,1);
ax1 = contour(rand(100,100),10);
colorbar;
xlabel('rows');
ylabel('columns');
title('Uniform Random Distribution');
subplot(1,2,2); 
contour(normrnd(0.5,0.17,[100,100]),10);
colorbar;
xlabel('rows');
ylabel('columns');
title('Gaussian Random Distribution');
