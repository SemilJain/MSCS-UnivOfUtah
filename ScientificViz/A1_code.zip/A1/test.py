import numpy as np
import matplotlib.pyplot as plt

# Uniform Random Sampling
np.random.seed(0)
uniform_rand_sample = np.random.sample((2,5000))

# Generate a 2D histogram with 100 bins
hist_uniform, xedges, yedges = np.histogram2d(uniform_rand_sample[0,:], uniform_rand_sample[1,:], bins=100)

print(hist_uniform)

# plt.imshow(hist_uniform)
# plt.title("Uniform Random Sampling")
# plt.xlabel("X")
# plt.ylabel("Y")
# plt.show()