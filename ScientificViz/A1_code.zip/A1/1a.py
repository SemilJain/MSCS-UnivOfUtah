import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


# To Plot BoxPlot
def plot_box(u_r, g_r):
    fig = plt.figure(figsize=(15, 5))
    ax1 = fig.add_subplot(1, 2, 1)
    ax1.boxplot(u_r)
    ax1.set_title("Uniform Random Distribution")
    ax2 = fig.add_subplot(1, 2, 2)
    ax2.boxplot(g_r)
    ax2.set_title("Gaussian Random Distribution")
    plt.show()


# Get Bin ranges between 2 values
def get_bins(low, high, size):
    bins = []
    start = low
    step = (low + high) / size
    for i in range(0, size + 1):
        bins.append(start)
        start = start + step
    return bins


# Get Data for Bar Plot
def get_bar_values(data, bins):
    df = pd.DataFrame(data).sort_values(by=0)
    df[1] = pd.cut(df[0], bins, include_lowest=True)
    return df[1].value_counts(sort=False)


# Plot Bar chart as histogram
def plot_bar(data1, data2):
    fig = plt.figure(figsize=(15, 5))
    ax1 = fig.add_subplot(1, 2, 1)
    data1.plot(kind='bar')
    ax1.set_title("Uniform Random Distribution")
    ax1.set_xlabel('bin ranges')
    ax1.set_ylabel('frequency in bins')
    ax2 = fig.add_subplot(1, 2, 2)
    data2.plot(kind='bar')
    ax2.set_title("Gaussian Random Distribution")
    ax2.set_xlabel('bin ranges')
    ax2.set_ylabel('frequency in bins')
    plt.show()


# Get data for Line
def get_line_data(data):
    file = open('file', 'wb')
    data.tofile(file)
    file.close()

    file = open('file', 'rb')
    read_list = list(file.read())
    file.close()

    x_axis = np.sort(read_list)
    y_axis = np.arange(1, len(x_axis) + 1) / float(len(x_axis))
    return [x_axis, y_axis]


# Plot line graph
def plot_line(data1, data2):
    fig = plt.figure(figsize=(15, 5))
    ax1 = fig.add_subplot(1, 2, 1)
    plt.plot(data1[0], data1[1])
    ax1.set_title("Uniform Random Distribution")
    ax1.set_xlabel('binary file values')
    ax1.set_ylabel('Cumulative probablity')
    ax2 = fig.add_subplot(1, 2, 2)
    plt.plot(data2[0], data2[1])
    ax2.set_title("Gaussian Random Distribution")
    ax2.set_xlabel('binary file values')
    ax2.set_ylabel('Cumulative probablity')
    plt.show()


# Plot scatter plot
def plot_scatter(data1, data2):
    fig = plt.figure(figsize=(15, 5))
    ax1 = fig.add_subplot(1, 2, 1)
    plt.scatter(data1[0], data1[1], marker='*')
    ax1.set_title("Uniform Random Distribution")
    ax1.set_xlabel('x coords')
    ax1.set_ylabel('y coords')
    ax2 = fig.add_subplot(1, 2, 2)
    plt.scatter(data2[0], data2[1], marker='*')
    ax2.set_title("Gaussian Random Distribution")
    ax2.set_xlabel('x coords')
    ax2.set_ylabel('y coords')
    plt.show()


# Plot Image
def plot_image(data1, data2):
    fig = plt.figure(figsize=(15, 5))
    ax1 = fig.add_subplot(1, 2, 1)
    plt.imshow(data1)
    plt.gca().invert_yaxis()
    ax1.set_title("Uniform Random Distribution")
    ax1.set_xlabel('x bins')
    ax1.set_ylabel('y bins')
    ax2 = fig.add_subplot(1, 2, 2)
    plt.imshow(data2)
    plt.gca().invert_yaxis()
    ax2.set_title("Gaussian Random Distribution")
    ax2.set_xlabel('x bins')
    ax2.set_ylabel('y bins')
    plt.show()


# plot Contour chart
def plot_contour(data1, data2):
    fig = plt.figure(figsize=(15, 5))
    ax1 = fig.add_subplot(1, 2, 1)
    uniform_rand_contour = ax1.contourf(data1, levels=10)
    ax1.set_title("Uniform Random Sampling")
    ax1.set_xlabel('rows')
    ax1.set_ylabel('columns')
    fig.colorbar(uniform_rand_contour, ax=ax1)
    ax2 = fig.add_subplot(1, 2, 2)
    gaussian_rand_contour = ax2.contourf(data2, levels=10)
    ax2.set_title("Gaussian Random Sampling")
    ax2.set_xlabel('rows')
    ax2.set_ylabel('columns')
    fig.colorbar(gaussian_rand_contour, ax=ax2)
    plt.show()


u_r = np.random.uniform(size=100)
g_r = np.random.normal(50, 17, 200)

plot_box(u_r, g_r)

bar1 = get_bar_values(u_r, get_bins(0, 1, 20))
bar2 = get_bar_values(g_r, get_bins(1, 110, 20))

plot_bar(bar1, bar2)
line1 = get_line_data(u_r)
line2 = get_line_data(g_r)
plot_line(line1, line2)

np.random.seed(0)
ur_2d = np.random.sample((2, 5000))
gr_2d = np.random.normal(0.5, 0.17, (2, 5000))

plot_scatter(ur_2d, gr_2d)

hist_uniform, xedges, yedges = np.histogram2d(ur_2d[0, :], ur_2d[1, :], bins=100)
hist_normal, xedges, yedges = np.histogram2d(gr_2d[0, :], gr_2d[1, :], bins=100)

plot_image(hist_uniform, hist_normal)

plot_contour(np.random.sample((100, 100)), np.random.normal(0.5, 0.17, (100, 100)))
