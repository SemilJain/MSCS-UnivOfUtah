import nibabel as nib
import matplotlib.pyplot as plt

# load the .nii data
img = nib.load('./T2.nii')

# extract the slices
slice_x = img.dataobj[:,:,128]
slice_y = img.dataobj[:,128,:]
slice_z = img.dataobj[128,:,:]

# Plot the slices as images with different colormap
plt.imshow(slice_x)
plt.gca().invert_yaxis()
plt.show()
plt.imshow(slice_x, cmap='gray')
plt.gca().invert_yaxis()
plt.show()
plt.imshow(slice_x, cmap='jet')
plt.gca().invert_yaxis()
plt.show()
