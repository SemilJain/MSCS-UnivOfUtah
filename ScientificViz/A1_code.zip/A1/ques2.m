T = readtable('./my.eng.utah.edu/~cs6635/NOAA-Temperatures.csv');
f1 = figure;
x = T.(1);
y = T.(2);
b = bar(x,y);
xlabel('Years');
ylabel('Degrees F +/- from Average');
b.FaceColor = 'flat';
for i = 1:size(y)
   if y(i) > 0
    b.CData(i,:) = [1, 0, 0];
   else
    b.CData(i,:) = [0,0,1];  
   end
end


T2 = readtable('./Breakfast-Cereals.xls', 'Range','1:4');
f2 = figure;
P = T2{:,[4:10,12]};
spider_plot(P,'AxesLimits',[100,0,0,150,0,10,0,50;150,10,5,300,5,20,10,120],'AxesLabels', {'Calories', 'Protein', 'Fat', 'Sodium', 'Fiber', 'Carbohydrates', 'Sugars', 'Potassium'}, 'FillOption', {'on', 'on', 'on'});
legend('Apple Cinnamon Cheerios', 'Basic 4', 'Cheerios');

T3 = readtable('./recentgrads.csv');
f3 = figure;
x = T3.(8) * 100;
y = T3.(16);

scatter(x,y);
xlabel('Percentage of Women in a Major');
ylabel('Median Salary in a Major');
title('Scatter Plot');


opts = detectImportOptions('./fandango.csv');
opts.SelectedVariableNames = {'FILM','RT_norm','Metacritic_norm','IMDB_norm','Fandango_Ratingvalue'};
T4 = readtable('./fandango.csv', opts);
f4 = figure;
P = T4{:,2:5};
labels = {'RT','Metacritic','IMDB','Fandango'};
parallelcoords(P, 'Labels', labels);
ylabel('Ratings');
title('Parallel Coords Plot');


