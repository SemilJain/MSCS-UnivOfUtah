import struct

with open('./stagbeetle832x832x494.dat', 'rb') as fp:
    vuSize = struct.unpack('<HHH', fp.read(6))
    uCount = vuSize[0] * vuSize[1] * vuSize[2]
    pData = struct.unpack(f'<{uCount}H', fp.read(uCount * 2))

with open('./stagbeetle832x832x494.raw', 'wb') as fp:
    for data in pData:
        fp.write(struct.pack('<H', data))
