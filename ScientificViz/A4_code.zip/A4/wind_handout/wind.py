#!/usr/bin/env python3

import numpy as np
import matplotlib.pyplot as plt

# Get data
vecs = np.reshape(np.fromfile("./wind_vectors.raw"), (20,20,2))
vecs_flat = np.reshape(vecs, (400,2)) # useful for plotting
vecs = vecs.transpose(1,0,2) # needed otherwise vectors don't match with plot

# X and Y coordinates of points where each vector is in space
xx, yy = np.meshgrid(np.arange(0, 20),np.arange(0, 20))

# Set random seed for reproducibility
# np.random.seed(42)
def bilinear_interpolation(x, y, data):
    x0 = int (x)
    y0 = int (y)
    x1 = min(x0 + 1, 19)
    y1 = min(y0 + 1, 19)
    dx = x - x0
    dy = y - y0
    vec_00 = data[x0, y0, :]
    vec_10 = data[x1, y0, :]
    vec_01 = data[x0, y1, :]
    vec_11 = data[x1, y1, :]
    w00 = (1 - dx) * (1 - dy)
    w10 = dx * (1 - dy)
    w01 = (1 - dx) * dy
    w11 = dx * dy
    p = w00 * vec_00 + w10 * vec_10 + w01 * vec_01 + w11 * vec_11
    return p

def plot_steps(step_size, num_steps):
    for i in range(len(seed_points)):
        streamline = [seed_points[i]]
        for j in range(num_steps):
            x = streamline[-1][0]
            y = streamline[-1][1]
            vec = bilinear_interpolation(x, y, vecs)
            dx = vec[0]
            dy = vec[1]
            x_new = x + step_size * dx
            y_new = y + step_size * dy
            # Bound x and y to data range
            x_new = np.clip(x_new, 0, 20)
            y_new = np.clip(y_new, 0, 20)
            # Stop tracing if we reach the image boundary
            if x_new == 0 or x_new == 20 or y_new == 0 or y_new == 20:
                break
            streamline.append([x_new, y_new])
        xs, ys = zip(*streamline)
        plt.plot(xs, ys, color='k')

np.random.seed(100)
seed_points = np.random.randint(0, 20, size=(15, 2))
print(seed_points)
x_seeds = np.random.randint(0, 20, size=15)
y_seeds = np.random.randint(0, 20, size=15)
# Plot vectors
plt.plot(xx, yy, marker='.', color='b', linestyle='none')

plot_steps(0.3, 8)
plt.quiver(xx, yy, vecs_flat[:,0], vecs_flat[:,1], width=0.001)
plt.title("Step size: 0.3, Steps = 8")
plt.show()
plot_steps(0.15, 16)
plt.quiver(xx, yy, vecs_flat[:,0], vecs_flat[:,1], width=0.001)
plt.title("Step size: 0.15, Steps = 16")
plt.show()
plot_steps(0.075, 32)
plt.quiver(xx, yy, vecs_flat[:,0], vecs_flat[:,1], width=0.001)
plt.title("Step size: 0.075, Steps = 32")
plt.show()
plot_steps(0.0375, 64)
plt.quiver(xx, yy, vecs_flat[:,0], vecs_flat[:,1], width=0.001)
plt.title("Step size: 0.0375, Steps = 64")
plt.show()

# plt.quiver(xx, yy, vecs_flat[:,0], vecs_flat[:,1], width=0.001)
# plt.scatter(x_seeds, y_seeds, color='r', marker='o')
# plt.title("Random Sampling (15 seed points)")
# plt.show()
