from paraview.simple import *

paraview.simple._DisableFirstRenderCameraReset()

a2dvti = XMLImageDataReader(registrationName='2d.vti', FileName=['/Users/u1417989/Desktop/ScientificViz/A2/data02/2d.vti'])
a2dvti.PointArrayStatus = ['Scalars_']

renderView1 = GetActiveViewOrCreate('RenderView')
a2dvtiDisplay = Show(a2dvti, renderView1, 'UniformGridRepresentation')

renderView1.Update()

# create a new 'Warp By Scalar'
warpByScalar1 = WarpByScalar(registrationName='WarpByScalar1', Input=a2dvti)
warpByScalar1.Scalars = ['POINTS', 'Scalars_']


warpByScalar1Display = Show(warpByScalar1, renderView1, 'StructuredGridRepresentation')

Hide(a2dvti, renderView1)

warpByScalar1Display.SetScalarBarVisibility(renderView1, True)
renderView1.Update()

#change interaction mode for render view
renderView1.InteractionMode = '3D'
renderView1.ResetCamera(True)

# layout1 = GetLayout()
# layout1.SetSize(2150, 828)
renderView1.CameraPosition = [973.7741426007498, -2753.535265579058, 8034.483968526139]
renderView1.CameraFocalPoint = [2047.9999999999998, 1024.0, 100.00000000000016]
renderView1.CameraViewUp = [-0.04014662219104938, 0.9042661882140618, 0.42507753360941125]
renderView1.CameraViewAngle = 14.492753623188406
renderView1.CameraParallelScale = 2291.3858252158234