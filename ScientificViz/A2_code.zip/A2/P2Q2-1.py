from paraview.simple import *

paraview.simple._DisableFirstRenderCameraReset()

a2dvti = XMLImageDataReader(registrationName='2d.vti', FileName=['/Users/u1417989/Desktop/ScientificViz/A2/data02/2d.vti'])
a2dvti.PointArrayStatus = ['Scalars_']

renderView1 = GetActiveViewOrCreate('RenderView')

a2dvtiDisplay = Show(a2dvti, renderView1, 'UniformGridRepresentation')

renderView1.ResetCamera(False)
renderView1.InteractionMode = '2D'
a2dvtiDisplay.SetScalarBarVisibility(renderView1, True)

renderView1.Update()

layout1 = GetLayout()

plotOverLine1 = PlotOverLine(registrationName='PlotOverLine1', Input=a2dvti)
lineChartView1 = CreateView('XYChartView')
plotOverLine1Display_1 = Show(plotOverLine1, lineChartView1, 'XYChartRepresentation')
AssignViewToLayout(view=lineChartView1, layout=layout1, hint=2)
lineChartView1.Update()
# SetActiveView(lineChartView1)
layout1.SetSize(2131, 828)