# trace generated using paraview version 5.11.0
#import paraview
#paraview.compatibility.major = 5
#paraview.compatibility.minor = 11

#### import the simple module from the paraview
from paraview.simple import *
from numpy import arange, pi, sin, cos, arccos
#### disable automatic camera reset on 'Show'
paraview.simple._DisableFirstRenderCameraReset()

def fibo_lattice(n=10):
    i = arange(0, n, dtype=float) + 0.5
    phi = arccos(1 - 2*i/n)
    goldenRatio = (1 + 5**0.5)/2
    theta = 2 * pi * i / goldenRatio
    x, y, z = cos(theta) * sin(phi), sin(theta) * sin(phi), cos(phi)
    result = [[xi, yi, zi] for xi, yi, zi in zip(x, y, z)]
    return result


# create a new 'Sphere'
sphere1 = Sphere(registrationName='Sphere1')

# Properties modified on sphere1
sphere1.Radius = 1.0

# get active view
renderView1 = GetActiveViewOrCreate('RenderView')

# show data in view
# sphere1Display = Show(sphere1, renderView1, 'GeometryRepresentation')


# init the 'PiecewiseFunction' selected for 'ScaleTransferFunction'
# sphere1Display.ScaleTransferFunction.Points = [-0.9749279022216797, 0.0, 0.5, 0.0, 0.9749279022216797, 1.0, 0.5, 0.0]

# init the 'PiecewiseFunction' selected for 'OpacityTransferFunction'
# sphere1Display.OpacityTransferFunction.Points = [-0.9749279022216797, 0.0, 0.5, 0.0, 0.9749279022216797, 1.0, 0.5, 0.0]

# reset view to fit data
# renderView1.ResetCamera(False)

# update the view to ensure updated data information
# renderView1.Update()

def create_spheres(points):
    j = 1
    for point in points:
        j = j + 1
        sphere_i = Sphere(registrationName='Sphere'+str(j))
        sphere_i.Center = point
        sphere_i.Radius = 0.1
        sphere_iDisplay = Show(sphere_i, renderView1, 'GeometryRepresentation')
        sphere_iDisplay.ScaleTransferFunction.Points = [-0.9749279022216797, 0.0, 0.5, 0.0, 0.9749279022216797, 1.0, 0.5, 0.0]
        sphere_iDisplay.OpacityTransferFunction.Points = [-0.9749279022216797, 0.0, 0.5, 0.0, 0.9749279022216797, 1.0, 0.5, 0.0]

renderView1.Update()

points = fibo_lattice(100)
create_spheres(points)

#================================================================
# addendum: following script captures some of the application
# state to faithfully reproduce the visualization during playback
#================================================================

# get layout
layout1 = GetLayout()

#--------------------------------
# saving layout sizes for layouts

# layout/tab size in pixels
layout1.SetSize(2150, 1350)

#-----------------------------------
# saving camera placements for views

# current camera placement for renderView1
renderView1.CameraPosition = [3.4983271813028085, 0.5601393556316921, 5.545647219193033]
renderView1.CameraViewUp = [-0.658500335558068, 0.6672890069627387, 0.3479981167428843]
renderView1.CameraParallelScale = 1.7032230708456042

#--------------------------------------------
# uncomment the following to render all views
# RenderAllViews()
# alternatively, if you want to write images, you can use SaveScreenshot(...).