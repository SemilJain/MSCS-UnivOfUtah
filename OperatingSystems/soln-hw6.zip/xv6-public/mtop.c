#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  /* Syscall invocation here */
  int mem = memtop();
  printf(1, "available memory: %d\n", mem);
  exit();
}

