#include "types.h"
#include "stat.h"
#include "fcntl.h"
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
    ;
  return os;
}

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
    p++, q++;
  return (uchar)*p - (uchar)*q;
}

uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
    ;
  return n;
}

void*
memset(void *dst, int c, uint n)
{
  stosb(dst, c, n);
  return dst;
}

char*
strchr(const char *s, char c)
{
  for(; *s; s++)
    if(*s == c)
      return (char*)s;
  return 0;
}

char*
gets(char *buf, int max)
{
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
  return buf;
}

int
stat(const char *n, struct stat *st)
{
  int fd;
  int r;

  fd = open(n, O_RDONLY);
  if(fd < 0)
    return -1;
  r = fstat(fd, st);
  close(fd);
  return r;
}

int
atoi(const char *s)
{
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
  return n;
}

void*
memmove(void *vdst, const void *vsrc, int n)
{
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
    *dst++ = *src++;
  return vdst;
}

void thread_spin_init(struct thread_spinlock *lk)
{
  lk->flag = 0;
}

void thread_spin_lock(struct thread_spinlock *lk){
  while(xchg(&lk->flag, 1) != 0);
}

void thread_spin_unlock(struct thread_spinlock *lk){
	xchg(&lk->flag, 0);
}

// void thread_queue_init(struct thread_queue *queue) {
//   queue->head = 0;
//   queue->tail = 0;
// }

void thread_mutex_init(struct thread_mutex *m) {
  m->locked = 0;
  // thread_queue_init(m->queue);
}

void thread_mutex_lock(struct thread_mutex *m) {
  while (xchg(&m->locked, 1) != 0) { // try to acquire lock
    // lock is already held, put thread to sleep and wait
    sleep(1);
  }
}

void thread_mutex_unlock(struct thread_mutex *m) {
  xchg(&m->locked, 0); // release lock
  // wakeup(m->queue); // wake up a sleeping thread
}

void thread_cond_init(struct thread_cond *cv) {
    cv->waiters = 0;
}

void thread_cond_signal(struct thread_cond *cv) {
    if (cv->waiters > 0) {
        cv->waiters--;
        thread_mutex_unlock(cv->m);
    }
}

int thread_cond_wait(struct thread_cond *cv, struct thread_mutex *m) {
    int rc = 0;
    cv->waiters++;

    thread_mutex_unlock(m);
    thread_mutex_lock(cv->m);

    while (cv->waiters > 0) {
        // wait for a signal
        sleep(1);
    }

    thread_mutex_unlock(cv->m);
    thread_mutex_lock(m);

    return rc;
}

int sem_init(struct sem_t *s, int value) {
    // if (pshared) { return -1; }

    // s->count = value;
    // thread_mutex_init(s->m);
    // thread_cond_init(s->cv);
    return 0;
}

void sem_post(struct sem_t *s) {
    // thread_mutex_lock(s->m);
    // s->count++;
    // thread_cond_signal(s->cv); /* See note */
    // /* A woken thread must acquire the lock, so it will also have to wait until we call unlock */

    // thread_mutex_unlock(s->m);
}

void sem_wait(struct sem_t *s) {
    // thread_mutex_lock(s->m);
    // while (s->count == 0) {
    //     thread_cond_wait(s->cv, s->m); /*unlock mutex, wait, relock mutex */
    // }
    // s->count--;
    // thread_mutex_unlock(s->m);
}
