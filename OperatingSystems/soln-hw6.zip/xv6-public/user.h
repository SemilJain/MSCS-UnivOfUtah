struct stat;
struct rtcdate;
struct thread_spinlock{
  uint flag;
};

struct sem_t {
  uint count; 
  struct thread_mutex *m;
  struct thread_cond *cv;
};

struct thread_cond {
  uint waiters;          
  struct thread_mutex *m;   
};

struct thread_mutex {
  uint locked; // 0 = unlocked, 1 = locked
  // struct thread_queue *queue; // queue of sleeping threads
};

// system calls
int fork(void);
int exit(void) __attribute__((noreturn));
int wait(void);
int pipe(int*);
int write(int, const void*, int);
int read(int, void*, int);
int close(int);
int kill(int);
int exec(char*, char**);
int open(const char*, int);
int mknod(const char*, short, short);
int unlink(const char*);
int fstat(int fd, struct stat*);
int link(const char*, const char*);
int mkdir(const char*);
int chdir(const char*);
int dup(int);
int getpid(void);
char* sbrk(int);
int sleep(int);
int uptime(void);
int memtop(void);
int thread_create(void(*fcn)(void*), void *arg, void*stack);
int thread_join(void);
int thread_exit(void);

// ulib.c
int stat(const char*, struct stat*);
char* strcpy(char*, const char*);
void *memmove(void*, const void*, int);
char* strchr(const char*, char c);
int strcmp(const char*, const char*);
void printf(int, const char*, ...);
char* gets(char*, int max);
uint strlen(const char*);
void* memset(void*, int, uint);
void* malloc(uint);
void free(void*);
int atoi(const char*);
void thread_spin_init(struct thread_spinlock *lk);
void thread_spin_lock(struct thread_spinlock *lk);
void thread_spin_unlock(struct thread_spinlock *lk);
void thread_mutex_init(struct thread_mutex *m);
void thread_mutex_lock(struct thread_mutex *m);
void thread_mutex_unlock(struct thread_mutex *m);
void thread_cond_init(struct thread_cond *cv);
void thread_cond_signal(struct thread_cond *cv);
int thread_cond_wait(struct thread_cond *cv, struct thread_mutex *m);
int sem_init(struct sem_t *s, int value);
void sem_post(struct sem_t *s);
void sem_wait(struct sem_t *s);
