int a[32]; // the global array

unsigned long crash_array(int n) {
    int i;
    unsigned long sum = 0;

    for (i = 0; i < n; i++) {
        sum = sum + a[i];
    }

    return sum;
}

unsigned long sum(int n) {
    int i;
    unsigned long sum = 0;
    for (i = 0; i < n; i++) {
        sum = sum + i;
    }

    return sum;
}

int main(void) {
    unsigned long s;

    s = sum(100);
    printf("Hello world, the sum:%ld\n", s);
    s = crash_array(32);
    printf("crash array sum:%ld\n", s);    
    return 0; 
}