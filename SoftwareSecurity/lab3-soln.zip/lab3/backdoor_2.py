#!/usr/bin/env python
  
import angr
import sys

def backdoor_symbolic_execution():
    p = angr.Project('login', auto_load_libs=False)
    state = p.factory.entry_state()
    simgr = p.factory.simgr(state)
    success_string = b'Access granted! You are now in the admin console!'
    while True:
        simgr.step()

        for active_state in simgr.active:
            if success_string in active_state.posix.dumps(1):
                print(f"Success string found in state {active_state}")
                password = active_state.posix.dumps(0)
                print(f"The backdoor password is: {password.decode()}")
                return password

        # If there are no active states, we've hit a dead end and can exit
        if len(simgr.active) == 0:
            print("Simulation reached a dead end")
            return "error"

if __name__ == '__main__':
    sys.stdout.buffer.write(backdoor_symbolic_execution())