#!/usr/bin/env python

import angr
import sys

def backdoor_symbolic_execution():

    p = angr.Project('login', auto_load_libs=False)

    state = p.factory.entry_state()
    sm = p.factory.simulation_manager(state)

    sm.run(until=lambda sm_: len(sm_.active) > 1)

    input_0 = sm.active[0].posix.dumps(0)
    input_1 = sm.active[1].posix.dumps(0)

    print(input_0.decode("latin-1"))
    print(input_1.decode("latin-1"))
    print("done")
    
    return input_0

if __name__ == '__main__':
    sys.stdout.buffer.write(backdoor_symbolic_execution())